
const jwt = require('jsonwebtoken');

// Authentication Middleware
const verifyToken = (req, res, next) => {
    try {
        // 1. Get token from request header
        const authHeader = req.headers.authorization;

        // 2. Check if token exists
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'Access denied. No token provided.'
            });
        }

        // 3. Extract token
        const token = authHeader.split(' ')[1];

        // 4. Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // 5. Store user information in request
        req.user = decoded;

        // 6. Allow request to continue
        next();

    } catch (error) {
        return res.status(401).json({
            success: false,
            message: 'Invalid or expired token'
        });
    }
};

module.exports = verifyToken;
