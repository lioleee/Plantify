
const express = require('express');
const router = express.Router();

const db = require('../config/db');
const verifyToken = require('../middleware/authMiddleware');

// GET ALL PLANTS OF LOGGED-IN USER
router.get('/', verifyToken, async (req, res) => {
    try {
        const userId = req.user.id;

        const [plants] = await db.execute(
            `SELECT
                id,
                user_id,
                name,
                species,
                category,
                health,
                watering_schedule,
                is_watered_today,
                last_watered,
                image_url
             FROM plants
             WHERE user_id = ?
             ORDER BY created_at DESC`,
            [userId]
        );

        return res.status(200).json({
            success: true,
            count: plants.length,
            plants
        });

    } catch (error) {
        console.error('Get plants error:', error.message);

        return res.status(500).json({
            success: false,
            message: 'Unable to fetch plants'
        });
    }
});

// CREATE A NEW PLANT
router.post('/', verifyToken, async (req, res) => {
    try {
        const {
            name,
            species,
            category,
            health,
            wateringSchedule,
            imageUrl
        } = req.body;

        // Validate required fields
        if (
            !name || typeof name !== 'string' || !name.trim() ||
            !species || typeof species !== 'string' || !species.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: 'Plant name and species are required'
            });
        }

        // Validate health
        const allowedHealth = ['Healthy', 'Needs Water', 'Critical'];

        if (health && !allowedHealth.includes(health)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid plant health value'
            });
        }

        // Validate watering schedule
        const allowedSchedules = [
            'Every 3 days',
            'Every 7 days',
            'Every 14 days',
            'Every 21 days'
        ];

        if (
            wateringSchedule &&
            !allowedSchedules.includes(wateringSchedule)
        ) {
            return res.status(400).json({
                success: false,
                message: 'Invalid watering schedule'
            });
        }

        // Insert plant into database
        const [result] = await db.execute(
            `INSERT INTO plants
            (user_id, name, species, category, health,
             watering_schedule, image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                req.user.id,
                name.trim(),
                species.trim(),
                category || 'Indoor',
                health || 'Healthy',
                wateringSchedule || 'Every 7 days',
                imageUrl || null
            ]
        );

        return res.status(201).json({
            success: true,
            message: 'Plant added successfully',
            plantId: result.insertId
        });

    } catch (error) {
        console.error('Create plant error:', error.message);

        return res.status(500).json({
            success: false,
            message: 'Unable to add plant'
        });
    }
});
// UPDATE AN EXISTING PLANT
router.put('/:id', verifyToken, async (req, res) => {
    try {
        const plantId = req.params.id;
        const userId = req.user.id;

        const {
            name,
            species,
            category,
            health,
            wateringSchedule,
            isWateredToday,
            lastWatered,
            imageUrl
        } = req.body;

        // Check whether plant belongs to logged-in user
        const [plants] = await db.execute(
            'SELECT id FROM plants WHERE id = ? AND user_id = ?',
            [plantId, userId]
        );

        if (plants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Plant not found'
            });
        }

        // Validate health
        const allowedHealth = ['Healthy', 'Needs Water', 'Critical'];

        if (health && !allowedHealth.includes(health)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid plant health value'
            });
        }

        // Validate watering schedule
        const allowedSchedules = [
            'Every 3 days',
            'Every 7 days',
            'Every 14 days',
            'Every 21 days'
        ];

        if (
            wateringSchedule &&
            !allowedSchedules.includes(wateringSchedule)
        ) {
            return res.status(400).json({
                success: false,
                message: 'Invalid watering schedule'
            });
        }

        const [result] = await db.execute(
            `UPDATE plants SET
                name = COALESCE(?, name),
                species = COALESCE(?, species),
                category = COALESCE(?, category),
                health = COALESCE(?, health),
                watering_schedule = COALESCE(?, watering_schedule),
                is_watered_today = COALESCE(?, is_watered_today),
                last_watered = COALESCE(?, last_watered),
                image_url = COALESCE(?, image_url)
             WHERE id = ? AND user_id = ?`,
            [
                name || null,
                species || null,
                category || null,
                health || null,
                wateringSchedule || null,
                typeof isWateredToday === 'boolean'
                    ? (isWateredToday ? 1 : 0)
                    : null,
                lastWatered || null,
                imageUrl || null,
                plantId,
                userId
            ]
        );

        return res.status(200).json({
            success: true,
            message: 'Plant updated successfully'
        });

    } catch (error) {
        console.error('Update plant error:', error.message);

        return res.status(500).json({
            success: false,
            message: 'Unable to update plant'
        });
    }
});
// DELETE A PLANT
router.delete('/:id', verifyToken, async (req, res) => {
    try {
        const plantId = req.params.id;
        const userId = req.user.id;

        const [result] = await db.execute(
            'DELETE FROM plants WHERE id = ? AND user_id = ?',
            [plantId, userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Plant not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Plant deleted successfully'
        });

    } catch (error) {
        console.error('Delete plant error:', error.message);

        return res.status(500).json({
            success: false,
            message: 'Unable to delete plant'
        });
    }
});
module.exports = router;
